document.addEventListener("DOMContentLoaded", function (event) {
    var hueData = document.getElementById("hueRange");
    var hue = eval(hueData.value);

    hueData.onchange = () => {
        $.ajax({
            type: "PUT",
            url: 'http://192.168.1.197/api/c8bo3zrs-ACXbMDxVq1AL80GQfON16CB9GKwgF40/lights/4/state',
            contentType: "application/json",
            data: JSON.stringify({ "hue": parseInt(hueData.value) })
        });
    }
});