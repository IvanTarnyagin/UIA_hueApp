var on = true;
function sendJson() {
    if (on === false) {
        $.ajax({
            type: "PUT",
            url: 'http://192.168.1.197/api/c8bo3zrs-ACXbMDxVq1AL80GQfON16CB9GKwgF40/lights/4/state',
            contentType: "application/json",
            data: JSON.stringify({ "on": true })
        });
        on = true;
    }
    else {
        $.ajax({
            type: "PUT",
            url: 'http://192.168.1.197/api/c8bo3zrs-ACXbMDxVq1AL80GQfON16CB9GKwgF40/lights/4/state',
            contentType: "application/json",
            data: JSON.stringify({ "on": false })
        });
        on = false;
    }
}