var hueSlider, satSlider, briSlider;

document.addEventListener("DOMContentLoaded", function (event) {

    // hue-ness
    hueSlider = document.getElementById("hueRange");
    var hueOutput = document.getElementById("hue");
    hueOutput.innerHTML = hueSlider.value;
    hueSlider.oninput = function () {
        hueOutput.innerHTML = this.value;
    }
    // saturation
    satSlider = document.getElementById("satRange");
    var satOutput = document.getElementById("sat");
    satOutput.innerHTML = satSlider.value;
    satSlider.oninput = function () {
        satOutput.innerHTML = this.value;
    }
    // brightness
    briSlider = document.getElementById("briRange");
    var briOutput = document.getElementById("bri");
    briOutput.innerHTML = briSlider.value;
    briSlider.oninput = function () {
        briOutput.innerHTML = this.value;
    }
    /*
//stuff
var request = new XMLHttpRequest()
if (briSlider.value < 100) {
console.log(0);
}
else {
console.log(1);
}
*/
});